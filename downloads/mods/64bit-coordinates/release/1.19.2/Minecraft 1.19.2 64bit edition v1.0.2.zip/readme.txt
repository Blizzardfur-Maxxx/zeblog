How to install: (Start from 6) https://github.com/Hexeption/MCP-Reborn#how-to-use

NOTICE: MCP Reborn cannot reobfuscate class. So I can only distribute jar file. But resources file is not included.

What need to fix:
- Light system. I took 3 hours to fix this. But doesn't work.
- Misc

Author: mckuhei
Bug report & delete requests: mckuheiqwq (at) gmail (dot) com

==== history ====
1.0.0:
      Inital release
=================
1.0.1:
      Add floating point precision display.
      Fix "No chunk holder after ticket has been added" exception
=================
1.0.2:
      Removed world border.
      Add a patch to fix chunk stripe lands.
      Add a patch to fix Frustum cause game froze.
      Add a patch to fix 'chunk out of bound' exception.
=================
