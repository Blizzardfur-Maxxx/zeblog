Frustrum patch: Fix Frustum cause game froze.
LevelRenderer patch: Fix chunk stripe lands.
NoiseBasedChunkGenerator patch: Fix 'chunk out of bound' exception.